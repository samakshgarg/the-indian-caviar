export const products = [
  // Fruit Caviars
  {
    name: "Mango Bliss Caviar",
    description: "Tropical Alphonso richness captured in delicate pearls.",
    price: 599,
    image: "https://images.unsplash.com/photo-1615486364155-0d76f9e3b25d?q=80&w=1200&auto=format&fit=crop",
    category: "Fruit Caviars"
  },
  {
    name: "Blueberry Royale Caviar",
    description: "Deep, jammy berries with a regal finish.",
    price: 699,
    image: "https://images.unsplash.com/photo-1562166433-4a9b3d8aa8a1?q=80&w=1200&auto=format&fit=crop",
    category: "Fruit Caviars"
  },
  {
    name: "Strawberry Élite Caviar",
    description: "Bright, elegant strawberries with a satin mouthfeel.",
    price: 649,
    image: "https://images.unsplash.com/photo-1514511543263-9f83537f9a2f?q=80&w=1200&auto=format&fit=crop",
    category: "Fruit Caviars"
  },

  // Coffee Caviars
  {
    name: "Espresso Noir Caviar",
    description: "Intense arabica espresso with a lingering cocoa finish.",
    price: 799,
    image: "https://images.unsplash.com/photo-1504630083234-14187a9df0f5?q=80&w=1200&auto=format&fit=crop",
    category: "Coffee Caviars"
  },
  {
    name: "Mocha Gold Caviar",
    description: "Silky chocolate harmonised with bold espresso.",
    price: 849,
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1200&auto=format&fit=crop",
    category: "Coffee Caviars"
  },
  {
    name: "Caramel Latte Caviar",
    description: "Buttery caramel sweetness balanced with fine roast.",
    price: 899,
    image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?q=80&w=1200&auto=format&fit=crop",
    category: "Coffee Caviars"
  }
];

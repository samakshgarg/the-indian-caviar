import Head from "next/head";
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import About from "../components/About";
import Products from "../components/Products";
import WhyChooseUs from "../components/WhyChooseUs";
import Contact from "../components/Contact";
import Newsletter from "../components/Newsletter";
import BlogPreview from "../components/BlogPreview";
import Footer from "../components/Footer";

export default function Home() {
  return (
    <>
      <Head>
        <title>THE INDIAN CAVIAR</title>
      </Head>
      <Navbar />
      <main>
        <Hero />
        <div className="hr-gold my-10" />
        <About />
        <Products />
        <WhyChooseUs />
        <Contact />
        <Newsletter />
        <BlogPreview />
      </main>
      <Footer />
    </>
  );
}

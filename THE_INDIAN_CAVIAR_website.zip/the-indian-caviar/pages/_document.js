import { Html, Head, Main, NextScript } from "next/document";

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        {/* Fonts */}
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Playfair+Display:wght@600;700&display=swap"
          rel="stylesheet"
        />
        {/* Basic SEO + OG */}
        <meta name="theme-color" content="#000000" />
        <meta name="title" content="THE INDIAN CAVIAR" />
        <meta
          name="description"
          content="Exquisite Fruit & Coffee Caviars for the Refined Palate."
        />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="THE INDIAN CAVIAR" />
        <meta
          property="og:description"
          content="Exquisite Fruit & Coffee Caviars for the Refined Palate."
        />
        <meta property="og:url" content="https://theindiancaviar.com" />
        <meta
          property="og:image"
          content="https://images.unsplash.com/photo-1541976076758-347942db1971?q=80&w=1600&auto=format&fit=crop"
        />
        <meta name="twitter:card" content="summary_large_image" />
      </Head>
      <body className="bg-black text-white">
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}

export default function Contact() {
  return (
    <section id="contact" className="py-16 md:py-20">
      <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-10">
        <div>
          <h2 className="text-3xl md:text-4xl">Contact</h2>
          <p className="mt-3 text-gray-300">Questions, wholesale, or custom events? Send us a note.</p>
          <div className="mt-6 space-y-2 text-gray-300 text-sm">
            <p>Email: <a className="text-gold" href="mailto:hello@theindiancaviar.com">hello@theindiancaviar.com</a></p>
            <p>WhatsApp: <a className="text-gold" href="https://wa.me/919266735566" target="_blank" rel="noreferrer">+91 92667 35566</a></p>
            <p>Location: India</p>
          </div>
        </div>

        {/* Formspree form – replace with your Formspree endpoint */}
        <form
          action="https://formspree.io/f/yourid"
          method="POST"
          className="bg-[#0b0b0b] border border-white/10 rounded-2xl p-6"
        >
          <label className="block text-sm">Name</label>
          <input name="name" required className="mt-1 w-full bg-black border border-white/10 rounded-md px-3 py-2" />

          <label className="block text-sm mt-4">Email</label>
          <input type="email" name="email" required className="mt-1 w-full bg-black border border-white/10 rounded-md px-3 py-2" />

          <label className="block text-sm mt-4">Message</label>
          <textarea name="message" rows="5" required className="mt-1 w-full bg-black border border-white/10 rounded-md px-3 py-2" />

          <button className="mt-6 w-full bg-gold text-black font-semibold rounded-full py-3 hover:opacity-90">
            Send Message
          </button>
        </form>
      </div>
    </section>
  );
}

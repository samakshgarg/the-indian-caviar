import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-black py-24" id="home">
      <div className="absolute -top-40 right-[-120px] h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.18)_0%,transparent_60%)] blur-2xl" />
      <div className="absolute -bottom-40 left-[-120px] h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.18)_0%,transparent_60%)] blur-2xl" />

      <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
        <motion.h1
          className="text-5xl md:text-6xl font-serif text-gold"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          THE INDIAN CAVIAR
        </motion.h1>
        <motion.p
          className="mt-6 text-lg md:text-xl text-gray-300 max-w-2xl mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.25, duration: 0.7 }}
        >
          Exquisite Fruit & Coffee Caviars for the Refined Palate
        </motion.p>
        <motion.div
          className="mt-8 flex justify-center gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.45, duration: 0.7 }}
        >
          <a
            href="https://wa.me/919266735566"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-gold text-black px-6 py-3 rounded-full font-semibold hover:opacity-90 shadow-soft"
          >
            Order on WhatsApp
          </a>
          <a
            href="#products"
            className="border border-gold text-gold px-6 py-3 rounded-full font-semibold hover:bg-gold hover:text-black"
          >
            View Products
          </a>
        </motion.div>
      </div>
    </section>
  );
}

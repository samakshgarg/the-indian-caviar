export default function Footer() {
  return (
    <footer className="border-t border-white/10 py-10">
      <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-sm text-gray-400">© {new Date().getFullYear()} THE INDIAN CAVIAR. All rights reserved.</p>
        <nav className="flex items-center gap-6 text-sm text-gray-300">
          <a href="#products" className="hover:text-white">Products</a>
          <a href="#contact" className="hover:text-white">Contact</a>
          <a href="https://wa.me/919266735566" target="_blank" rel="noreferrer" className="text-gold hover:opacity-90">Order on WhatsApp</a>
        </nav>
      </div>
    </footer>
  );
}

const posts = [
  {
    title: "Pairing Fruit Caviar with Champagne",
    excerpt: "Balance acidity and sweetness for the perfect toast.",
    href: "#"
  },
  {
    title: "Coffee Caviar: The New Luxury Trend",
    excerpt: "How modern kitchens are plating coffee like never before.",
    href: "#"
  },
  {
    title: "Behind the Scenes at THE INDIAN CAVIAR",
    excerpt: "A peek at our small-batch process and sourcing.",
    href: "#"
  }
];

export default function BlogPreview() {
  return (
    <section className="py-16 md:py-20 bg-[linear-gradient(180deg,rgba(212,175,55,0.06),rgba(0,0,0,0))]">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl md:text-4xl">From the Caviar Journal</h2>
        <div className="grid md:grid-cols-3 gap-6 mt-8">
          {posts.map((p) => (
            <a key={p.title} href={p.href} className="block border border-white/10 rounded-2xl p-6 bg-[#0b0b0b] hover:border-gold">
              <h4 className="text-lg font-serif text-gold">{p.title}</h4>
              <p className="mt-2 text-sm text-gray-300">{p.excerpt}</p>
              <span className="inline-block mt-4 text-gold text-sm">Read →</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function Newsletter() {
  return (
    <section className="py-14">
      <div className="max-w-3xl mx-auto px-6 text-center">
        <h3 className="text-2xl">Join the Caviar Journal</h3>
        <p className="text-gray-300 mt-2">Be the first to know about new releases and limited drops.</p>
        {/* Replace action with your Mailchimp/ConvertKit endpoint later */}
        <form className="mt-5 flex gap-2 justify-center">
          <input
            type="email"
            required
            placeholder="you@example.com"
            className="bg-black border border-white/10 rounded-full px-4 py-3 w-full max-w-xs"
          />
          <button className="bg-gold text-black font-semibold rounded-full px-5">
            Subscribe
          </button>
        </form>
      </div>
    </section>
  );
}

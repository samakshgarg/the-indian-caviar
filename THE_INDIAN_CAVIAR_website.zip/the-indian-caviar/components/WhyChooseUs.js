const perks = [
  { title: "100% Natural Ingredients", desc: "Real fruits and premium coffee extracts only." },
  { title: "Handcrafted Batches", desc: "Consistent texture, clarity, and snap." },
  { title: "Luxury Presentation", desc: "Refined packaging ready for gifting & service." },
  { title: "Nationwide Shipping", desc: "Secure cold-chain ready logistics available." },
];

export default function WhyChooseUs() {
  return (
    <section className="py-16 md:py-20 bg[linear-gradient(0deg,rgba(212,175,55,0.06),rgba(0,0,0,0))]">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl md:text-4xl">Why Choose Us</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {perks.map((p) => (
            <div key={p.title} className="border border-white/10 rounded-2xl p-5 bg-[#0b0b0b]">
              <h4 className="text-lg font-serif text-gold">{p.title}</h4>
              <p className="mt-2 text-sm text-gray-300">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { products } from "../data/products";

export default function Products() {
  const groups = {
    "Fruit Caviars": products.filter(p => p.category === "Fruit Caviars"),
    "Coffee Caviars": products.filter(p => p.category === "Coffee Caviars")
  };

  return (
    <section id="products" className="py-16 md:py-20">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl md:text-4xl mb-6">Products & Pricing</h2>
        <p className="text-gray-300 max-w-3xl">
          Premium pearls designed to finish plates, cocktails, and tasting menus. All prices are per 100g.
        </p>

        {Object.entries(groups).map(([title, list]) => (
          <div key={title} className="mt-10">
            <h3 className="text-2xl mb-4 text-gold">{title}</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {list.map((item) => (
                <div key={item.name} className="rounded-2xl overflow-hidden border border-white/10 bg-[#0b0b0b]">
                  <div className="aspect-[4/3] overflow-hidden">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover hover:scale-[1.03] transition-transform" />
                  </div>
                  <div className="p-5">
                    <h4 className="text-xl font-serif text-gold">{item.name}</h4>
                    <p className="mt-2 text-gray-300 text-sm">{item.description}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <span className="text-lg font-semibold">₹{item.price}</span>
                      <a
                        href={`https://wa.me/919266735566?text=I'd like to order: ${encodeURIComponent(item.name)} - ₹${item.price}/100g`}
                        target="_blank"
                        rel="noreferrer"
                        className="border border-gold text-gold px-4 py-2 rounded-full text-sm hover:bg-gold hover:text-black"
                      >
                        Order Now
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

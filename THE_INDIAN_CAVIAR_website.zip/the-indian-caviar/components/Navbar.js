export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-black/70 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-5 h-16 flex items-center justify-between">
        <a href="#" className="text-xl font-serif text-gold tracking-wide">
          THE INDIAN CAVIAR
        </a>
        <nav className="hidden md:flex items-center gap-8 text-sm text-gray-300">
          <a href="#about" className="hover:text-white">About</a>
          <a href="#products" className="hover:text-white">Products</a>
          <a href="#contact" className="hover:text-white">Contact</a>
          <a
            href="https://wa.me/919266735566"
            target="_blank"
            rel="noreferrer"
            className="bg-gold text-black px-4 py-2 rounded-full font-semibold hover:opacity-90"
          >
            Order Now
          </a>
        </nav>
        <a href="#contact" className="md:hidden text-sm text-gold">Contact</a>
      </div>
    </header>
  );
}

export default function About() {
  return (
    <section id="about" className="py-16 md:py-20 bg-[linear-gradient(180deg,rgba(212,175,55,0.06),rgba(0,0,0,0))]">
      <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h2 className="text-3xl md:text-4xl">Crafted for the Connoisseur</h2>
          <p className="mt-4 text-gray-300 leading-relaxed">
            THE INDIAN CAVIAR reimagines indulgence with fruit and coffee caviars
            that burst with flavour and elegance. Handcrafted in small batches,
            our pearls elevate desserts, cocktails, and tasting menus with a
            dramatic finish.
          </p>
          <p className="mt-4 text-gray-300">
            From Alphonso mango to espresso noir, every sphere is calibrated for
            clarity, texture, and a luxurious mouthfeel.
          </p>
        </div>
        <div className="rounded-2xl overflow-hidden border border-white/10">
          <img
            src="https://images.unsplash.com/photo-1543353071-10c8ba85a904?q=80&w=1600&auto=format&fit=crop"
            alt="Luxury plating"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
